(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_6abf0e29._.js",
  "static/chunks/src_components_b492e48c._.js"
],
    source: "dynamic"
});
