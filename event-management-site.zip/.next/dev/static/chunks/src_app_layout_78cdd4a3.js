(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a3dce129._.css",
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_df05b4dd._.js",
  "static/chunks/node_modules_next_4f71bef8._.js",
  "static/chunks/node_modules_@clerk_shared_dist_runtime_ed887137._.js",
  "static/chunks/node_modules_swr_dist_1add123d._.js",
  "static/chunks/node_modules_@clerk_clerk-react_dist_6fd342e9._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_gi_index_mjs_657583d5._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_a70b904e._.js",
  "static/chunks/src_components_Navbar_jsx_8e3901e4._.js"
],
    source: "dynamic"
});
