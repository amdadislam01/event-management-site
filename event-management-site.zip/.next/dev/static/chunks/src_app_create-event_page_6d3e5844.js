(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e676c3ee._.js",
  "static/chunks/src_app_create-event_EventForm_jsx_e3ee8f40._.js"
],
    source: "dynamic"
});
